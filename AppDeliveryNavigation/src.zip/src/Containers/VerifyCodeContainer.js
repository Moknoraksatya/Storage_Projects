import {connect} from 'react-redux'
import VerifyCode from '../Screens/VerifyCode'
const mapStateToProps= state =>({

})
const mapDispatchToProps = {
}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(VerifyCode)
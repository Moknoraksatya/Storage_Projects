import {connect} from 'react-redux'
import ChangeBank from '../Screens/ChangeBank'
const mapStateToProps= state =>({

})
const mapDispatchToProps = {
}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(ChangeBank)
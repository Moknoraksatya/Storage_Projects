import {connect} from 'react-redux'
import ScreenLoading from '../Screens/ScreenLoading'
const mapStateToProps = state =>({

})
const mapDispatchToProps ={

}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(ScreenLoading)
import {connect} from 'react-redux'
import Report from '../Screens/Report'
const mapStateToProps = state =>({

})
const mapDispatchToProps ={

}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(Report)
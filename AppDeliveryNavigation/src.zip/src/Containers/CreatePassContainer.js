import {connect} from 'react-redux'
import CreatePass from '../Screens/CreatePass'
import {function1} from '../..'
const mapStateToProps = state =>({
    ...state
})
const mapDispatchToProps ={
    function1
}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(CreatePass)
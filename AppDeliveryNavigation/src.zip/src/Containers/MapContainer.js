import {connect} from 'react-redux'
import ScreenMap from '../Screens/ScreenMap'
const mapStateToProps = state =>({

})
const mapDispatchToProps ={

}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(ScreenMap)
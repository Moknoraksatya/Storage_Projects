import {connect} from 'react-redux'
import ScreenPhoneCall from '../Screens/ScreenPhoneCall'
const mapStateToProps = state =>({

})
const mapDispatchToProps ={

}
export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(ScreenPhoneCall)
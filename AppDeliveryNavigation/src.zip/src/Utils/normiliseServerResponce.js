const normalize = res => res.data;
export default normalize;

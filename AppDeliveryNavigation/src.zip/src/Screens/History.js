// import React,{Component} from 'react'
// import {
//     Text,
//     StyleSheet,
//     Image,
//     View,
//     TouchableOpacity,
// } from 'react-native'
// import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons'
// import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
// import NavigationService from '../Service/navigationService'
// import { NAV_TYPES } from '../Navigation/navTypes'
// export default class History extends Component{
//     constructor(prop){
//         super(prop)
//         this.state={
           
//         } 
//     }
//     render(){
//         return(
//             <>
//                 <View style={styles.container}>
//                     <View style={styles.inner}>
//                         <View style={styles.benner}>
//                             <Image
//                                 style={styles.centerLogo}
//                                 source={require('../Assets/images/WhiteLogo.png')}
//                             />
//                         </View>     
//                     </View>
//                     <View flex={0.03}
//                         style={{
//                             borderBottomColor: 'white',
//                             borderBottomWidth: 1, Top:50,
//                         }}
//                     />
//                     <TouchableOpacity style={styles.branch}
//                         onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
//                         <View style={styles.imageBox}>
//                             <Image style={styles.Logo}
//                                 source={require('../Assets/images/instock.png')}
//                             />
                            
//                             {/* <MaterialCommunityIcons style={styles.rightLogo} name="file-document-edit-outline" size={33} color={'#ffffff'}> </MaterialCommunityIcons> */}
//                         </View>
//                         <View style={styles.ListTitleBox}>
//                             <Text style={styles.ListTitle}>ប្រវត្តិបញ្ញើសរុប</Text>
//                         </View>
//                         <View style={styles.iconBox}>
//                             <SimpleLineIcons style={{fontWeight:'bold'}} name="arrow-right" size={15} color={'#ffffff'}> </SimpleLineIcons>
//                         </View>
                        
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.branch}
//                         onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
//                         <View style={styles.imageBox}>
//                             <Image style={styles.Logo}
//                                 source={require('../Assets/images/verify02.png')}
//                             />
//                             {/* <MaterialCommunityIcons style={styles.rightLogo} name="file-document-outline" size={33} color={'#ffffff'}> </MaterialCommunityIcons> */}
                            
//                         </View>
//                         <View style={styles.ListTitleBox}>
//                             <Text style={styles.ListTitle}>ប្រវត្តិបញ្ញើជោគជ័យ</Text>
//                         </View>
//                         <View style={styles.iconBox}>
//                             <SimpleLineIcons style={{fontWeight:'bold'}} name="arrow-right" size={15} color={'#ffffff'}> </SimpleLineIcons>
//                         </View>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.branch}
//                         onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
//                         <View style={styles.imageBox}>
//                             <Image style={styles.Logo}
//                                 source={require('../Assets/images/remove01.png')}
//                             />
//                             {/* <MaterialCommunityIcons style={styles.rightLogo} name="file-undo-outline" size={33} color={'#ffffff'}> </MaterialCommunityIcons> */}
                            
//                         </View>
//                         <View style={styles.ListTitleBox}>
//                             <Text style={styles.ListTitle}>ប្រវត្តិបញ្ញើបរាជ័យ</Text>
//                         </View>
//                         <View style={styles.iconBox}>
//                             <SimpleLineIcons style={{fontWeight:'bold'}} name="arrow-right" size={15} color={'#ffffff'}> </SimpleLineIcons>
//                         </View>
//                     </TouchableOpacity>
//                     <TouchableOpacity style={styles.branch}
//                         onPress={()=>{NavigationService.navigate(NAV_TYPES.DELAY)}}>
//                         <View style={styles.imageBox}>
//                             <Image style={styles.Logo}
//                                 source={require('../Assets/images/timer.png')}
//                             />
//                             {/* <MaterialCommunityIcons style={styles.rightLogo} name="timer-outline" size={33} color={'#ffffff'}> </MaterialCommunityIcons> */}
//                         </View>
//                         <View style={styles.ListTitleBox}>
//                             <Text style={styles.ListTitle}>ឥវ៉ាន់ពន្យាពេលទទួល</Text>
//                         </View>
//                         <View style={styles.iconBox}>
//                             <SimpleLineIcons style={{fontWeight:'bold'}} name="arrow-right" size={15} color={'#ffffff'}> </SimpleLineIcons>
//                         </View>
//                     </TouchableOpacity>
//                     {/* <View style={styles.listContainer}>
//                         <TouchableOpacity style={styles.list}
//                             onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
//                                 <View style={styles.imageBox} >
//                                     <Image
//                                         style={styles.Logo}
//                                         source={require('../Assets/images/RFP.jpg')}
//                                     />
//                                 </View>
//                                 <View style={styles.listTitleBox} >
//                                     <Text style={styles.text}>ប្រវត្តិបញ្ញើសរុប</Text>
//                                 </View>
//                         </TouchableOpacity>
//                     </View>
//                     <View style={styles.listContainer}>
//                         <TouchableOpacity style={styles.list}
//                             onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
//                             <View style={styles.imageBox} >
//                                 <Image
//                                     style={styles.Logo}
//                                     source={require('../Assets/images/SuccessTick.jpg')}
//                                 />
//                             </View>
//                             <View style={styles.listTitleBox} >
//                             <Text style={styles.text}>ប្រវត្តិបញ្ញើជោគជ័យ</Text>
//                             </View>
//                         </TouchableOpacity>
//                     </View>
//                     <View style={styles.listContainer}>
//                         <TouchableOpacity style={styles.list}
//                             onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
//                             <View style={styles.imageBox} >
//                                 <Image
//                                     style={styles.Logo}
//                                     source={require('../Assets/images/unSuccess.jpg')}
//                                 />
//                             </View>
//                             <View style={styles.listTitleBox} >
//                             <Text style={styles.text}>ប្រវត្តិបញ្ញើបរាជ័យ</Text>
//                             </View>
//                         </TouchableOpacity>
//                     </View>
//                     <View style={styles.listContainerLast}>
//                         <TouchableOpacity style={styles.list}
//                             onPress={()=>{NavigationService.navigate(NAV_TYPES.DELAY)}}>
//                                 <View style={styles.imageBox} >
//                                     <Image
//                                         style={styles.Logo1} 
//                                         source={require('../Assets/images/delay-Clock.jpg')}
//                                     />
//                                 </View>
//                             <View style={styles.listTitleBox} >
//                                 <Text style={styles.text}>ឥវ៉ាន់ពន្យាពេលទទួល</Text>
//                             </View> 
//                         </TouchableOpacity>
//                     </View> */}
//                 </View>
//             </>
//         )
//     }
// }
// const styles = StyleSheet.create({
//     container:{
//         flex: 1,
//         backgroundColor: '#02475e',
//     },  
//     inner:{
//         flex: 0.15,
//         flexDirection: 'row',
//         justifyContent: 'center',
//         backgroundColor: '#02475e',
//     },
//     centerLogo: {
//         flex: 1,
//         width: 180,
//         height: 100,
//         marginTop:30
//     },
//     branch:{
//         flex: 0.08,
//         flexDirection:'row',
//         borderBottomColor:'white',
//         borderBottomWidth:1,
//     },
//     imageBox:{
//         flex:0.2,
//         // flexDirection:'row',
//         // backgroundColor:'skyblue',
//         justifyContent:'center',
//         alignItems:'center'
//     },
//     Logo:{
//         width: 30,
//         height: 30,
//         // marginLeft: 20,
//     },
//     ListTitleBox:{
//         flex:0.7,
//         flexDirection:'row',
//         alignItems:'center',
//         // paddingLeft:20,
//         // backgroundColor:'orange',
//     },
//     iconBox:{
//         flex:0.1,
//         flexDirection:'row',
//         justifyContent:'center',
//         alignItems:'center',
//         marginRight:10,
//         // backgroundColor:'red',
//     },
//     ListTitle:{
//        color:"white",
//        fontSize:14,
//        marginLeft:20,
//        fontFamily:'KhmerOScontent',
//     },
//     HeaderTitle:{
//         flex:0.25,
//         flexDirection:'row',
//         backgroundColor:'#ffffff',
//         justifyContent:'center',
//         alignItems:'center',
//         textAlign:'center',
//         borderTopEndRadius:10,
//         borderTopStartRadius:10,
//         borderBottomColor:'grey',
//         borderBottomWidth:1,
//     },
//     listRadio:{
//         backgroundColor:'#ffffffaa',
//         flex:0.5,
//         flexDirection:'row',
//         color:'white',
//         fontSize:18,textAlign:'center',
//         justifyContent:'center',
//         alignItems:'center',
//         paddingLeft:'5%',
//         paddingTop:25,
//     },
//     footerBtn:{
//         flex:0.25,
//         flexDirection:'row',
//         backgroundColor:'#fb3640',
//         justifyContent:'center',
//         alignItems:'center',
//         textAlign:'center',
//         borderBottomEndRadius:10,
//         borderBottomStartRadius:10,
//     },
//     // listContainer:{
//     //     flex: 0.08,
//     //     flexDirection:'row',
//     //     backgroundColor: '#02475e',
//     //     padding: 10,
//     //     paddingBottom: 0,
//     // },
//     // listContainerLast:{
//     //     flex: 0.08,
//     //     flexDirection:'row',
//     //     backgroundColor: '#02475e',
//     //     padding: 10,
//     // },
//     // list:{
//     //     flex: 1,
//     //     flexDirection:'row',
//     //     backgroundColor:'white',
//     //     borderRadius: 5,
//     // },
//     // imageBox:{
//     //     flex:0.35,
//     //     flexDirection:'row',
//     //     // backgroundColor: 'red',
//     //     // justifyContent:'center',
//     //     alignItems: 'center',
//     // },
//     // listTitleBox:{
//     //     flex:0.65,
//     //     flexDirection:'row',
//     //     // backgroundColor: 'yellow',
//     //     // justifyContent:'center',
//     //     alignItems: 'center',
//     // },
//     // Logo:{
//     //     width: 40,
//     //     height: 40,
//     //     marginLeft: 20,
//     // },
//     // Logo1:{
//     //     width: 50,
//     //     height: 50,
//     //     marginLeft: 12,
//     // },
//     // text:{
//     //     fontSize: 20,
//     //     color: 'black',
//     //     fontWeight:'bold',
//     // },
    





//     // btn: {
//     //     flex: 1,
//     //     flexDirection: 'row',
//     //     backgroundColor: 'green',
//     //     marginRight: 10,
//     // },
//     // benner: {
//     //     flex: 1,
//     //     justifyContent: 'center',
//     //     alignItems: 'center',
//     // },
//     // inner1:{
//     //     flex: 0.1,
//     //     flexDirection: 'row'
//     // },
   
//     // benner1: {
//     //     flex: 0.30,
//     //     backgroundColor: 'white',
//     //     justifyContent: 'center',
//     // },
//     // benner2: {
//     //     flex: 1,
//     //     borderColor: 'skyblue',
//     //     borderBottomWidth: 2,
//     //     borderTopWidth: 2,
//     //     justifyContent: 'center',
//     //     alignItems: 'center',
//     //     backgroundColor: 'white',
//     // },
//     // benner3: {
//     //     flex: 1,
//     //     borderColor: 'skyblue',
//     //     borderBottomWidth: 2,
//     //     justifyContent: 'center',
//     //     alignItems: 'center',
//     //     backgroundColor: 'white',
//     // },
//     // text:{
//     //     fontSize: 20,
//     //     color: 'skyblue',
//     // },
    
//     // Logo: {
//     //     flex: 0.8,
//     //     width: 50,
//     //     height: 45,
//     //     marginLeft: 20,
//     // },
 
//   });
  
import React,{Component} from 'react'
import {
    Text,
    StyleSheet,
    Image,
    View,
    TouchableOpacity,
} from 'react-native'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import NavigationService from '../Service/navigationService'
import { NAV_TYPES } from '../Navigation/navTypes'
export default class History extends Component{
    constructor(prop){
        super(prop)
        this.state={
           
        } 
    }
    render(){
        return(
            <>
                <View style={styles.container}>
                    <View style={styles.inner}>
                        <View style={styles.btnBack}>
                            <TouchableOpacity onPress={()=>{NavigationService.navigate(NAV_TYPES.MAIN_HOME01)}}>
                                <MaterialIcons
                                    style={{fontWeight:'bold',color:'#005792',marginRight:'5%',fontSize:40}} name="keyboard-arrow-left" size={15} color={'#ffffff'}> 
                                </MaterialIcons>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.benner}>
                            <Image
                                style={styles.centerLogo}
                                source={require('../Assets/images/logoMST.png')}
                            />
                        </View>    
                        <View style={styles.btnBack}>

                        </View>
                    </View>
                    <View style={styles.listContainer}>
                        <TouchableOpacity style={styles.list}
                            onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
                                <View style={styles.imageBox} >
                                    <Image
                                        style={styles.Logo}
                                        source={require('../Assets/images/RFP.jpg')}
                                    />
                                </View>
                                <View style={styles.listTitleBox} >
                                    <Text style={styles.text}>ប្រវត្តិបញ្ញើសរុប</Text>
                                </View>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.listContainer}>
                        <TouchableOpacity style={styles.list}
                            onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
                            <View style={styles.imageBox} >
                                <Image
                                    style={styles.Logo}
                                    source={require('../Assets/images/SuccessTick.jpg')}
                                />
                            </View>
                            <View style={styles.listTitleBox} >
                            <Text style={styles.text}>ប្រវត្តិបញ្ញើជោគជ័យ</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.listContainer}>
                        <TouchableOpacity style={styles.list}
                            onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
                            <View style={styles.imageBox} >
                                <Image
                                    style={styles.Logo}
                                    source={require('../Assets/images/unSuccess.jpg')}
                                />
                            </View>
                            <View style={styles.listTitleBox} >
                            <Text style={styles.text}>ប្រវត្តិបញ្ញើបរាជ័យ</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.listContainerLast}>
                        <TouchableOpacity style={styles.list}
                            onPress={()=>{NavigationService.navigate(NAV_TYPES.RESULTPACKAGE)}}>
                                <View style={styles.imageBox} >
                                    <Image
                                        style={styles.Logo1} 
                                        source={require('../Assets/images/delay-Clock.jpg')}
                                    />
                                </View>
                            <View style={styles.listTitleBox} >
                                <Text style={styles.text}>ឥវ៉ាន់ពន្យាពេលទទួល</Text>
                            </View> 
                        </TouchableOpacity>
                    </View>
                </View>
            </>
        )
    }
}
const styles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor: 'white',
    },  
    inner:{
        flex: 0.15,
        flexDirection: 'row',
        // justifyContent: 'center',
        // backgroundColor: 'yellow',
    },
    btnBack:{
        flex: 0.2,
        flexDirection: 'row',
        justifyContent:'center',
        alignItems:'center',
        // backgroundColor: 'red',
    },
    listContainer:{
        flex: 0.1,
        flexDirection:'row',
        backgroundColor: '#d4e3fa',
        padding: 10,
        paddingBottom: 0,
    },
    listContainerLast:{
        flex: 0.1,
        flexDirection:'row',
        backgroundColor: '#d4e3fa',
        padding: 10,
    },
    list:{
        flex: 1,
        flexDirection:'row',
        backgroundColor:'white',
        borderRadius: 5,
    },
    imageBox:{
        flex:0.35,
        flexDirection:'row',
        // backgroundColor: 'red',
        // justifyContent:'center',
        alignItems: 'center',
    },
    listTitleBox:{
        flex:0.65,
        flexDirection:'row',
        // backgroundColor: 'yellow',
        // justifyContent:'center',
        alignItems: 'center',
    },
    Logo:{
        width: 40,
        height: 40,
        marginLeft: 20,
    },
    Logo1:{
        width: 50,
        height: 50,
        marginLeft: 12,
    },
    text:{
        fontSize: 18,
        color: 'black',
        fontFamily:'KhmerOScontent',
    },
    centerLogo: {
        flex: 1,
        width: 150,
        height: 80,
    },





    // btn: {
    //     flex: 1,
    //     flexDirection: 'row',
    //     backgroundColor: 'green',
    //     marginRight: 10,
    // },
    benner: {
        flex: 0.6,
        justifyContent: 'center',
        alignItems: 'center',
    },
    // inner1:{
    //     flex: 0.1,
    //     flexDirection: 'row'
    // },
   
    // benner1: {
    //     flex: 0.30,
    //     backgroundColor: 'white',
    //     justifyContent: 'center',
    // },
    // benner2: {
    //     flex: 1,
    //     borderColor: 'skyblue',
    //     borderBottomWidth: 2,
    //     borderTopWidth: 2,
    //     justifyContent: 'center',
    //     alignItems: 'center',
    //     backgroundColor: 'white',
    // },
    // benner3: {
    //     flex: 1,
    //     borderColor: 'skyblue',
    //     borderBottomWidth: 2,
    //     justifyContent: 'center',
    //     alignItems: 'center',
    //     backgroundColor: 'white',
    // },
    // text:{
    //     fontSize: 20,
    //     color: 'skyblue',
    // },
    
    // Logo: {
    //     flex: 0.8,
    //     width: 50,
    //     height: 45,
    //     marginLeft: 20,
    // },
 
  });
  
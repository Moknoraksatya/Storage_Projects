
import appReducer from "../Modules/app/reducer";
import homeReducer from "../Modules/home/reducer"
export default {
  app: appReducer,
  home:homeReducer
};

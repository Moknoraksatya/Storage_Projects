const http = require('http');
const app = require('./app');

const hostname = '192.168.1.100';
// const hostname = '172.20.10.4';
const port = 3010;

const server = http.createServer(app);

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
